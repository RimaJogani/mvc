<?php
namespace Model\Category;

\Mage::loadFileByClassName('Model\Core\Table\Collection');

class Collection extends \Model\Core\Table\Collection
{
    
}
?>