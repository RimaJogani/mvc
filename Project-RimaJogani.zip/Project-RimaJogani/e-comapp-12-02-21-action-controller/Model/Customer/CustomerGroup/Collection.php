<?php
namespace Model\Customer\CustomerGroup;
\Mage::loadFileByClassName('Model\Core\Table\Collection');

class Collection extends \Model\Core\Table\Collection
{
    
}
?>