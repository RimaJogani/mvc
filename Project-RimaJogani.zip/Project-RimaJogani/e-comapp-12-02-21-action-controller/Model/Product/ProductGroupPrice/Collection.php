<?php
namespace Model\Product\ProductGroupPrice;

\Mage::loadFileByClassName('Model\Core\Table\Collection');

class Collection extends \Model\Core\Table\Collection
{
    
}
?>