<section>
       <div class="container pt-4 mx-auto">
       		<div class="leftBar">
                  <?php echo $this->getTabHtml();?>
            </div>
            <div class="col-md-7 mx-auto">
                  <?php echo $this->getTabContent();?>
              </div>
       </div>
</section>

   