<section>
       <div class="container pt-4 mx-auto">
            <div class="bg-light p-5 rounded mx-auto">
              <div class="col-md-7 mx-auto col-lg-8 mt-4">
                  <?php echo $this->getTabContent(); ?>
              </div>
            </div>
       </div>
</section>

  