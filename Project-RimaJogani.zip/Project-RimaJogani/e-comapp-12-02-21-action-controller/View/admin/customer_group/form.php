 <section>
       <div class="container pt-4 mx-auto">
              <div class="col-md-7 mx-auto col-lg-8 mt-4">
                <form class="needs-validation" novalidate="" id="customerGroupForm" action="<?php echo $this->getUrl('Customer_CustomerGroup','save');?>" method="post">
                  <?php echo $this->getTabContent(); ?>
                </form>
              </div>
       </div>
   </section>

   
  
  