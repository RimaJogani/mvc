<section>
       <div class="container pt-4 mx-auto">
              <div class="col-md-7 mx-auto col-lg-8 mt-4">
               <div id="ContentHtml">
                   <?php echo $this->getTabContent();?>
             </div>
              </div>
       </div>
   </section>
